from pytest import main

from arithmetic_arranger import arithmetic_arranger
 

print(arithmetic_arranger(["32 + 8", "1 - 3801", "9999 + 99999", "523 - 49", "23 + 49"], True))


# Run unit tests automatically
main()
